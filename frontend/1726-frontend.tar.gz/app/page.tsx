"use client"

import CybersecurityDashboard from "./cybersecurity-dashboard"

export default function Page() {
  return <CybersecurityDashboard />
}
